document.addEventListener("DOMContentLoaded", () => {
  const freteRates = {
    SP: { standard: 15.0, fast: 25.0, express: 40.0 },
    RJ: { standard: 18.0, fast: 28.0, express: 45.0 },
    MG: { standard: 20.0, fast: 30.0, express: 50.0 },
    default: { standard: 25.0, fast: 35.0, express: 60.0 },
  }

  let selectedEndereco = null
  const selectedFrete = null
  let selectedPagamento = null
  let currentCep = null
  let montagemId = null

  // Check URL params for montagem
  const urlParams = new URLSearchParams(window.location.search)
  montagemId = urlParams.get("montagem_id")

  function loadInitialTotals() {
    if (montagemId) {
      return
    }

    fetch("../Carrinho/cartAPI.php?action=getCart")
      .then((response) => response.json())
      .then((data) => {
        if (data.produtos && data.produtos.length > 0) {
          let resumo = '<div class="summary-section">'
          let subtotal = 0

          data.produtos.forEach((produto) => {
            const total = Number.parseFloat(produto.precoProduto) * Number.parseInt(produto.quantidade)
            subtotal += total
            resumo += `
                            <div class="summary-item">
                                <span>${produto.nomeProduto}</span>
                                <span>R$ ${total.toFixed(2).replace(".", ",")}</span>
                            </div>
                        `
          })

          resumo += "</div>"
          document.getElementById("resumo-produtos").innerHTML = resumo
          updateTotals()
        }
      })
      .catch((error) => console.error("[v0] Error loading cart:", error))
  }

  function formatCurrency(value) {
    return "R$ " + value.toFixed(2).replace(".", ",")
  }

  function updateTotals() {
    let subtotal = 0

    if (montagemId) {
      const montagemText = document.getElementById("subtotal-montagem")
      if (montagemText) {
        const value = montagemText.textContent.match(/[\d,]+/)
        subtotal = Number.parseFloat(value[0].replace(",", "."))
      }
    } else {
      const produtos = document.querySelectorAll("#resumo-produtos .summary-item span:last-child")
      produtos.forEach((el) => {
        const value = Number.parseFloat(el.textContent.replace("R$ ", "").replace(",", "."))
        subtotal += value
      })
    }

    const freteEl = document.querySelector('input[name="frete"]:checked')
    const freteCost = freteEl ? Number.parseFloat(freteEl.dataset.cost) : 0
    const total = subtotal + freteCost

    document.getElementById("subtotal").textContent = formatCurrency(subtotal)
    document.getElementById("frete").textContent = formatCurrency(freteCost)
    document.getElementById("total").textContent = formatCurrency(total)
  }

  function searchCep() {
    const cepInput = document.getElementById("cepInput")
    const cep = cepInput.value.replace(/\D/g, "")

    if (cep.length !== 8) {
      showAlert("CEP inválido. Digite um CEP com 8 dígitos.", "error")
      return
    }

    fetch(`https://viacep.com.br/ws/${cep}/json/`)
      .then((response) => response.json())
      .then((data) => {
        if (data.erro) {
          showAlert("CEP não encontrado.", "error")
          return
        }

        currentCep = cep
        document.getElementById("street").value = data.logradouro
        document.getElementById("neighborhood").value = data.bairro
        document.getElementById("city").value = data.localidade
        document.getElementById("state").value = data.uf
        document.getElementById("resultadoEndereco").style.display = "block"

        document.querySelectorAll(".endereco-radio").forEach((radio) => {
          radio.checked = false
        })
        document.querySelectorAll(".endereco-card").forEach((card) => {
          card.classList.remove("selected")
        })
        selectedEndereco = null

        updateShippingOptions(data.uf)
      })
      .catch((error) => {
        console.error("[v0] CEP search error:", error)
        showAlert("Erro ao buscar CEP. Tente novamente.", "error")
      })
  }

  function updateShippingOptions(state) {
    const rates = freteRates[state] || freteRates["default"]
    const freteDiv = document.getElementById("freteOptions")

    freteDiv.innerHTML = `
            <label class="frete-option">
                <input type="radio" name="frete" value="standard" data-cost="${rates.standard}">
                <div class="frete-info">
                    <div>
                        <strong>Frete Padrão</strong>
                        <span class="frete-tempo">5-7 dias úteis</span>
                    </div>
                    <span class="frete-cost">${formatCurrency(rates.standard)}</span>
                </div>
            </label>
            <label class="frete-option">
                <input type="radio" name="frete" value="fast" data-cost="${rates.fast}">
                <div class="frete-info">
                    <div>
                        <strong>Frete Rápido</strong>
                        <span class="frete-tempo">2-4 dias úteis</span>
                    </div>
                    <span class="frete-cost">${formatCurrency(rates.fast)}</span>
                </div>
            </label>
            <label class="frete-option">
                <input type="radio" name="frete" value="express" data-cost="${rates.express}">
                <div class="frete-info">
                    <div>
                        <strong>Frete Expresso</strong>
                        <span class="frete-tempo">1-2 dias úteis</span>
                    </div>
                    <span class="frete-cost">${formatCurrency(rates.express)}</span>
                </div>
            </label>
        `

    document.querySelectorAll('input[name="frete"]').forEach((radio) => {
      radio.addEventListener("change", updateTotals)
    })
  }

  function useNewAddress() {
    const street = document.getElementById("street").value
    const number = document.getElementById("number").value
    const neighborhood = document.getElementById("neighborhood").value
    const city = document.getElementById("city").value
    const state = document.getElementById("state").value

    if (!number) {
      showAlert("Por favor, digite o número do endereço.", "error")
      return
    }

    selectedEndereco = {
      type: "new",
      rua: street,
      numero: number,
      bairro: neighborhood,
      cidade: city,
      estado: state,
      cep: currentCep,
    }

    updateShippingOptions(state)
    showAlert("Endereço selecionado! Agora escolha a opção de frete.", "info")
  }

  document.querySelectorAll(".endereco-card").forEach((card) => {
    card.addEventListener("click", function (e) {
      const radio = this.querySelector(".endereco-radio")
      const isCurrentlySelected = this.classList.contains("selected")

      if (isCurrentlySelected) {
        // Deselect if clicking on already selected card
        radio.checked = false
        card.classList.remove("selected")
        selectedEndereco = null
        document.getElementById("resultadoEndereco").style.display = "none"
        document.getElementById("freteOptions").innerHTML =
          '<p class="loading-message">Selecione um endereço para ver opções de frete</p>'
      } else {
        // Remove selected from all other cards and select this one
        document.querySelectorAll(".endereco-card").forEach((c) => {
          c.classList.remove("selected")
        })
        document.querySelectorAll(".endereco-radio").forEach((r) => {
          r.checked = false
        })

        radio.checked = true
        card.classList.add("selected")

        // Get CEP from card and auto-fill input
        const cepElement = card.querySelector(".cep")
        const cep = cepElement ? cepElement.textContent.replace(/\D/g, "") : ""
        if (document.getElementById("cepInput") && cep) {
          document.getElementById("cepInput").value = cep.replace(/(\d{5})(\d{3})/, "$1-$2")
        }

        selectedEndereco = {
          type: "saved",
          idEndereco: radio.value,
        }
        document.getElementById("resultadoEndereco").style.display = "none"
        updateShippingOptions(radio.dataset.estado)
      }
    })
  })

  document.getElementById("searchCepBtn").addEventListener("click", searchCep)
  document.getElementById("cepInput").addEventListener("keypress", (e) => {
    if (e.key === "Enter") searchCep()
  })

  document.getElementById("usarNovoEndereco").addEventListener("click", useNewAddress)

  document.querySelectorAll(".pagamento-card").forEach((card) => {
    card.addEventListener("click", function (e) {
      const radio = this.querySelector(".pagamento-radio")
      const isCurrentlySelected = this.classList.contains("selected")

      if (isCurrentlySelected) {
        // Deselect if clicking on already selected card
        radio.checked = false
        card.classList.remove("selected")
        selectedPagamento = null
        document.querySelectorAll('input[name="novo_pagamento_tipo"]').forEach((r) => {
          r.checked = false
        })
        document.getElementById("cartaoForm").style.display = "none"
        document.getElementById("pixForm").style.display = "none"
        document.getElementById("boletoForm").style.display = "none"
      } else {
        // Remove selected from all other payment options
        document.querySelectorAll(".pagamento-card").forEach((c) => {
          c.classList.remove("selected")
        })
        document.querySelectorAll(".pagamento-radio").forEach((r) => {
          r.checked = false
        })
        document.querySelectorAll('input[name="novo_pagamento_tipo"]').forEach((r) => {
          r.checked = false
        })

        radio.checked = true
        card.classList.add("selected")
        selectedPagamento = {
          type: "saved",
          id: radio.value,
        }
        document.getElementById("cartaoForm").style.display = "none"
        document.getElementById("pixForm").style.display = "none"
        document.getElementById("boletoForm").style.display = "none"
      }
    })
  })

  document.querySelectorAll('input[name="novo_pagamento_tipo"]').forEach((radio) => {
    radio.addEventListener("change", function () {
      // Remove selected state from saved payment cards
      document.querySelectorAll(".pagamento-card").forEach((card) => {
        card.classList.remove("selected")
      })
      document.querySelectorAll(".pagamento-radio").forEach((r) => {
        r.checked = false
      })

      // Hide all forms first
      document.getElementById("cartaoForm").style.display = "none"
      document.getElementById("pixForm").style.display = "none"
      document.getElementById("boletoForm").style.display = "none"

      if (this.value === "cartao_credito") {
        document.getElementById("cartaoForm").style.display = "block"
      } else if (this.value === "pix") {
        document.getElementById("pixForm").style.display = "block"
      } else if (this.value === "boleto") {
        document.getElementById("boletoForm").style.display = "block"
      }

      selectedPagamento = {
        type: "new",
        metodo: this.value,
      }
    })
  })

  // Card formatting
  document.getElementById("numeroCartao").addEventListener("input", function () {
    this.value = this.value
      .replace(/\D/g, "")
      .replace(/(\d{4})/g, "$1 ")
      .trim()
  })

  document.getElementById("validadeCartao").addEventListener("input", function () {
    this.value = this.value.replace(/\D/g, "").replace(/(\d{2})(\d{2})/, "$1/$2")
  })

  document.getElementById("cvvCartao").addEventListener("input", function () {
    this.value = this.value.replace(/\D/g, "")
  })

  document.getElementById("finalizarBtn").addEventListener("click", () => {
    if (!selectedEndereco) {
      showAlert("Por favor, selecione um endereço de entrega.", "error")
      return
    }

    const freteRadio = document.querySelector('input[name="frete"]:checked')
    if (!freteRadio) {
      showAlert("Por favor, selecione uma opção de frete.", "error")
      return
    }

    if (!selectedPagamento) {
      showAlert("Por favor, selecione um método de pagamento.", "error")
      return
    }

    if (selectedPagamento.type === "new") {
      const metodo = selectedPagamento.metodo

      if (metodo === "cartao_credito") {
        const nome = document.getElementById("nomeCartao").value.trim()
        const numero = document.getElementById("numeroCartao").value.replace(/\D/g, "")
        const validade = document.getElementById("validadeCartao").value
        const cvv = document.getElementById("cvvCartao").value

        if (!nome) {
          showAlert("Por favor, digite o nome do titular do cartão.", "error")
          return
        }
        if (numero.length !== 16) {
          showAlert("Número do cartão inválido. Deve ter 16 dígitos.", "error")
          return
        }
        if (!validade || validade.length !== 5) {
          showAlert("Validade inválida. Use o formato MM/AA.", "error")
          return
        }
        if (cvv.length < 3 || cvv.length > 4) {
          showAlert("CVV inválido. Deve ter 3 ou 4 dígitos.", "error")
          return
        }
      } else if (metodo === "pix") {
        const chave = document.getElementById("chavePix").value.trim()
        if (!chave) {
          showAlert("Por favor, digite uma chave PIX válida.", "error")
          return
        }
      }
    }

    showConfirmationModal(selectedEndereco, freteRadio, selectedPagamento)
  })

  document.querySelectorAll(".btn-cancel").forEach((btn) => {
    btn.addEventListener("click", function (e) {
      if (this.id !== "cancelarBtn") {
        e.preventDefault()
        if (confirm("Tem certeza que deseja cancelar a compra?")) {
          // Redirect to home with cancelation message
          window.location.href = "../Home/index.php?status=compra_cancelada"
        }
      }
    })
  })

  function showConfirmationModal(endereco, frete, pagamento) {
    let enderecoDados = ""
    if (endereco.type === "new") {
      enderecoDados = `${endereco.rua}, ${endereco.numero} - ${endereco.bairro}, ${endereco.cidade} - ${endereco.estado}`
    } else {
      const card = document.querySelector(`input[value="${endereco.idEndereco}"]`).closest(".endereco-card")
      enderecoDados = card.textContent
    }

    const freteLabel = frete.closest(".frete-option").querySelector("strong").textContent
    const freteCost = Number.parseFloat(frete.dataset.cost)

    const resumoHTML = `
            <div style="margin-bottom: 15px;">
                <strong>Endereço:</strong><br>
                ${enderecoDados}
            </div>
            <div style="margin-bottom: 15px;">
                <strong>Frete:</strong><br>
                ${freteLabel} - ${formatCurrency(freteCost)}
            </div>
            <div style="margin-bottom: 15px;">
                <strong>Pagamento:</strong><br>
                ${pagamento.type === "saved" ? "Método salvo" : "Novo método"}
            </div>
        `

    document.getElementById("modalResumo").innerHTML = resumoHTML
    document.getElementById("confirmModal").style.display = "flex"

    document.getElementById("confirmarBtn").onclick = () => processCheckout(endereco, frete, pagamento)

    document.getElementById("cancelarBtn").onclick = () => {
      document.getElementById("confirmModal").style.display = "none"
    }
  }

  function processCheckout(endereco, frete, pagamento) {
    document.getElementById("confirmModal").style.display = "none"
    document.getElementById("finalizarBtn").disabled = true
    document.getElementById("finalizarBtn").textContent = "Processando..."

    const freteRadio = frete
    const freteCost = Number.parseFloat(freteRadio.dataset.cost)

    let idEndereco = null
    if (endereco.type === "saved") {
      idEndereco = endereco.idEndereco
    } else {
      idEndereco = 1
    }

    let pagamentoData = {}
    if (pagamento.type === "saved") {
      pagamentoData = { id: pagamento.id }
    } else {
      pagamentoData = {
        tipo: pagamento.metodo,
        nomeTitular: document.getElementById("nomeCartao")?.value || null,
        numeroCartao: document.getElementById("numeroCartao")?.value || null,
        validadeCartao: document.getElementById("validadeCartao")?.value || null,
        chavePix: document.getElementById("chavePix")?.value || null,
      }
    }

    const checkoutData = {
      action: "finalizarPedido",
      endereco: idEndereco,
      freteType: freteRadio.value,
      freteCost: freteCost,
      pagamentoId: pagamento.type === "saved" ? pagamento.id : 0,
      novoPagamento: pagamento.type === "new" ? pagamentoData : null,
      montagemId: montagemId || null,
    }

    fetch("checkoutAPI.php", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(checkoutData),
    })
      .then((response) => response.json())
      .then((data) => {
        if (data.success) {
          showAlert(`Pedido #${data.pedidoId} realizado com sucesso! Total: ${formatCurrency(data.total)}`, "success")
          window.location.href = "../Perfil/perfil.php"
        } else {
          showAlert("Erro ao finalizar compra: " + data.message, "error")
          document.getElementById("finalizarBtn").disabled = false
          document.getElementById("finalizarBtn").textContent = "Finalizar Compra"
        }
      })
      .catch((error) => {
        console.error("[v0] Checkout error:", error)
        showAlert("Erro ao processar sua compra.", "error")
        document.getElementById("finalizarBtn").disabled = false
        document.getElementById("finalizarBtn").textContent = "Finalizar Compra"
      })
  }

  function showAlert(message, type = "info") {
    const alertDiv = document.createElement("div")
    alertDiv.className = `custom-alert alert-${type}`
    alertDiv.textContent = message

    const style = document.createElement("style")
    if (!document.querySelector("style[data-alerts]")) {
      style.setAttribute("data-alerts", "true")
      style.textContent = `
        .custom-alert {
          position: fixed;
          top: 20px;
          right: 20px;
          padding: 15px 20px;
          border-radius: 8px;
          font-weight: 500;
          z-index: 10000;
          animation: slideIn 0.3s ease-out;
          max-width: 400px;
        }
        .alert-error {
          background-color: #fee;
          color: #c33;
          border: 1px solid #fcc;
        }
        .alert-success {
          background-color: #efe;
          color: #3c3;
          border: 1px solid #cfc;
        }
        .alert-info {
          background-color: #eef;
          color: #33c;
          border: 1px solid #ccf;
        }
        @keyframes slideIn {
          from {
            transform: translateX(400px);
            opacity: 0;
          }
          to {
            transform: translateX(0);
            opacity: 1;
          }
        }
      `
      document.head.appendChild(style)
    }

    document.body.appendChild(alertDiv)
    setTimeout(() => {
      alertDiv.style.animation = "slideOut 0.3s ease-in"
      setTimeout(() => alertDiv.remove(), 300)
    }, 4000)
  }

  loadInitialTotals()
})
