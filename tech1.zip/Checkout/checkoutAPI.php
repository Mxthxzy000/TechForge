<?php
session_start();
require_once '../config.php';

header('Content-Type: application/json');

// Verificar se usuário está logado
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Usuário não autenticado']);
    exit;
}

// Receber dados JSON
$input = json_decode(file_get_contents('php://input'), true);

if (!$input) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Dados inválidos']);
    exit;
}

$user_id = $_SESSION['user_id'];
$address = $input['address'] ?? null;
$shipping = $input['shipping'] ?? null;
$payment = $input['payment'] ?? null;

// Validações
if (!$address || !$shipping || !$payment) {
    echo json_encode(['success' => false, 'message' => 'Dados de pedido incompletos']);
    exit;
}

try {
    $conn->begin_transaction();

    // Obter total do carrinho
    $query_cart = "SELECT SUM(price * quantity) as total FROM cart WHERE user_id = ?";
    $stmt = $conn->prepare($query_cart);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result_cart = $stmt->get_result()->fetch_assoc();
    $cart_total = $result_cart['total'] ?? 0;

    // Calcular total com frete
    $shipping_cost = $shipping['cost'];
    $order_total = $cart_total + $shipping_cost;

    // Criar pedido
    $status = 'pending';
    $query_order = "INSERT INTO orders (user_id, total, shipping_cost, status, created_at) VALUES (?, ?, ?, ?, NOW())";
    $stmt = $conn->prepare($query_order);
    $stmt->bind_param("idds", $user_id, $order_total, $shipping_cost, $status);
    $stmt->execute();
    $order_id = $conn->insert_id;

    // Salvar endereço do pedido
    $query_order_address = "INSERT INTO order_addresses (order_id, street, number, complement, neighborhood, city, state, cep) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($query_order_address);
    $stmt->bind_param(
        "isssssss",
        $order_id,
        $address['street'],
        $address['number'],
        $address['complement'] ?? null,
        $address['neighborhood'],
        $address['city'],
        $address['state'],
        $address['cep']
    );
    $stmt->execute();

    // Salvar método de frete
    $query_shipping = "INSERT INTO order_shipping (order_id, type, cost) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($query_shipping);
    $stmt->bind_param("isd", $order_id, $shipping['type'], $shipping['cost']);
    $stmt->execute();

    // Processar pagamento (educacional - apenas registra)
    if ($payment['type'] === 'saved') {
        $query_payment = "INSERT INTO order_payments (order_id, payment_method_id, status) VALUES (?, ?, 'completed')";
        $stmt = $conn->prepare($query_payment);
        $stmt->bind_param("ii", $order_id, $payment['id']);
        $stmt->execute();
    } else {
        // Novo método de pagamento
        $payment_method = $payment['method'];
        $query_insert_method = "INSERT INTO payment_methods (user_id, payment_method, is_default) VALUES (?, ?, 0)";
        $stmt = $conn->prepare($query_insert_method);
        $stmt->bind_param("is", $user_id, $payment_method);
        $stmt->execute();
        $payment_method_id = $conn->insert_id;

        // Registrar pagamento do pedido
        $query_payment = "INSERT INTO order_payments (order_id, payment_method_id, status) VALUES (?, ?, 'completed')";
        $stmt = $conn->prepare($query_payment);
        $stmt->bind_param("ii", $order_id, $payment_method_id);
        $stmt->execute();
    }

    // Copiar itens do carrinho para o pedido
    $query_cart_items = "SELECT product_id, quantity, price FROM cart WHERE user_id = ?";
    $stmt = $conn->prepare($query_cart_items);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result_items = $stmt->get_result();

    $query_insert_item = "INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)";
    while ($item = $result_items->fetch_assoc()) {
        $stmt = $conn->prepare($query_insert_item);
        $stmt->bind_param(
            "iiid",
            $order_id,
            $item['product_id'],
            $item['quantity'],
            $item['price']
        );
        $stmt->execute();
    }

    // Limpar carrinho
    $query_clear_cart = "DELETE FROM cart WHERE user_id = ?";
    $stmt = $conn->prepare($query_clear_cart);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();

    // Confirmar transação
    $conn->commit();

    echo json_encode([
        'success' => true,
        'message' => 'Compra finalizada com sucesso',
        'order_id' => $order_id
    ]);

} catch (Exception $e) {
    $conn->rollback();
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Erro ao processar pedido: ' . $e->getMessage()
    ]);
}

$conn->close();
?>
