let selectedAddress = null
const selectedShipping = null
let selectedPayment = null
let currentCep = null
const shippingRates = {
  default: { standard: 10.0, fast: 20.0, express: 30.0 },
  SP: { standard: 15.0, fast: 25.0, express: 35.0 },
  RJ: { standard: 12.0, fast: 22.0, express: 32.0 },
}
const cartTotal = 100.0

// Formatar CEP
function formatCep(cep) {
  return cep.replace(/\D/g, "").replace(/(\d{5})(\d{3})/, "$1-$2")
}

// Buscar endereço por CEP usando ViaCEP
async function searchCep() {
  const cepInput = document.getElementById("cepInput")
  const cep = cepInput.value.replace(/\D/g, "")

  if (cep.length !== 8) {
    alert("CEP inválido. Digite um CEP válido.")
    return
  }

  try {
    const response = await fetch(`https://viacep.com.br/ws/${cep}/json/`)
    const data = await response.json()

    if (data.erro) {
      alert("CEP não encontrado.")
      return
    }

    currentCep = cep
    document.getElementById("street").value = data.logradouro
    document.getElementById("neighborhood").value = data.bairro
    document.getElementById("city").value = data.localidade
    document.getElementById("state").value = data.uf
    document.getElementById("addressResult").style.display = "block"

    // Deselecionar endereços salvos
    document.querySelectorAll(".address-radio").forEach((radio) => (radio.checked = false))
    selectedAddress = null

    // Atualizar opções de frete
    updateShippingOptions(data.uf)
  } catch (error) {
    console.error("[v0] CEP search error:", error)
    alert("Erro ao buscar CEP. Tente novamente.")
  }
}

// Atualizar opções de frete
function updateShippingOptions(state) {
  const rates = shippingRates[state] || shippingRates["default"]
  const shippingOptionsDiv = document.getElementById("shippingOptions")

  shippingOptionsDiv.innerHTML = `
        <label class="shipping-option">
            <input type="radio" name="shipping" value="standard" data-cost="${rates.standard}">
            <div class="shipping-info">
                <strong>Padrão (5-7 dias)</strong>
                <span class="shipping-cost">R$ ${rates.standard.toFixed(2).replace(".", ",")}</span>
            </div>
        </label>
        <label class="shipping-option">
            <input type="radio" name="shipping" value="fast" data-cost="${rates.fast}">
            <div class="shipping-info">
                <strong>Rápido (2-4 dias)</strong>
                <span class="shipping-cost">R$ ${rates.fast.toFixed(2).replace(".", ",")}</span>
            </div>
        </label>
        <label class="shipping-option">
            <input type="radio" name="shipping" value="express" data-cost="${rates.express}">
            <div class="shipping-info">
                <strong>Expresso (1-2 dias)</strong>
                <span class="shipping-cost">R$ ${rates.express.toFixed(2).replace(".", ",")}</span>
            </div>
        </label>
    `

  // Adicionar listeners aos shipping options
  document.querySelectorAll('input[name="shipping"]').forEach((radio) => {
    radio.addEventListener("change", updateTotal)
  })
}

// Usar novo endereço
function useNewAddress() {
  const street = document.getElementById("street").value
  const number = document.getElementById("number").value
  const neighborhood = document.getElementById("neighborhood").value
  const city = document.getElementById("city").value
  const state = document.getElementById("state").value

  if (!number) {
    alert("Por favor, digite o número do endereço.")
    return
  }

  selectedAddress = {
    street,
    number,
    neighborhood,
    city,
    state,
    cep: currentCep,
  }

  updateShippingOptions(state)
}

// Selecionar endereço salvo
document.addEventListener("DOMContentLoaded", () => {
  // Event listeners para endereços salvos
  document.querySelectorAll(".address-radio").forEach((radio) => {
    radio.addEventListener("change", function () {
      const cep = this.dataset.cep
      const state = cep.substring(0, 2)
      selectedAddress = { cep }
      updateShippingOptions(state)

      // Limpar formulário de novo endereço
      document.getElementById("addressResult").style.display = "none"
      document.getElementById("cepInput").value = ""
    })
  })

  // Buscar CEP ao clicar no botão
  document.getElementById("searchCepBtn").addEventListener("click", searchCep)

  // Enter no input de CEP
  document.getElementById("cepInput").addEventListener("keypress", (e) => {
    if (e.key === "Enter") {
      searchCep()
    }
  })

  // Selecionar novo endereço
  document.getElementById("selectNewAddressBtn").addEventListener("click", useNewAddress)

  // Métodos de pagamento
  document.querySelectorAll('input[name="payment_method"]').forEach((radio) => {
    radio.addEventListener("change", function () {
      selectedPayment = {
        id: this.value,
        type: "saved",
      }
    })
  })

  // Tipo de pagamento novo
  document.querySelectorAll('input[name="new_payment_type"]').forEach((radio) => {
    radio.addEventListener("change", function () {
      document.getElementById("cardForm").style.display = "none"
      document.getElementById("pixForm").style.display = "none"

      if (this.value === "credit_card" || this.value === "debit_card") {
        document.getElementById("cardForm").style.display = "block"
        document.querySelectorAll('input[name="payment_method"]').forEach((r) => (r.checked = false))
      } else if (this.value === "pix") {
        document.getElementById("pixForm").style.display = "block"
        document.querySelectorAll('input[name="payment_method"]').forEach((r) => (r.checked = false))
      }

      selectedPayment = {
        type: "new",
        method: this.value,
      }
    })
  })

  // Formatar número do cartão
  document.getElementById("cardNumber").addEventListener("input", function () {
    this.value = this.value
      .replace(/\D/g, "")
      .replace(/(\d{4})/g, "$1 ")
      .trim()
  })

  // Formatar validade
  document.getElementById("cardExpiry").addEventListener("input", function () {
    this.value = this.value.replace(/\D/g, "").replace(/(\d{2})(\d{2})/, "$1/$2")
  })

  // Formatar CVV
  document.getElementById("cardCVV").addEventListener("input", function () {
    this.value = this.value.replace(/\D/g, "")
  })

  // Finalizar compra
  document.getElementById("finalizeBtn").addEventListener("click", finalizeCheckout)
})

// Atualizar total
function updateTotal() {
  const shippingRadio = document.querySelector('input[name="shipping"]:checked')
  if (!shippingRadio) return

  const shippingCost = Number.parseFloat(shippingRadio.dataset.cost)
  const total = cartTotal + shippingCost

  document.getElementById("shipping-cost").textContent = `R$ ${shippingCost.toFixed(2).replace(".", ",")}`
  document.getElementById("total-amount").textContent = `R$ ${total.toFixed(2).replace(".", ",")}`
}

// Finalizar compra
function finalizeCheckout() {
  // Validações
  if (!selectedAddress) {
    alert("Por favor, selecione um endereço de entrega.")
    return
  }

  const shippingRadio = document.querySelector('input[name="shipping"]:checked')
  if (!shippingRadio) {
    alert("Por favor, selecione uma opção de frete.")
    return
  }

  if (!selectedPayment) {
    alert("Por favor, selecione um método de pagamento.")
    return
  }

  // Preparar dados
  const checkoutData = {
    address: selectedAddress,
    shipping: {
      type: shippingRadio.value,
      cost: Number.parseFloat(shippingRadio.dataset.cost),
    },
    payment: selectedPayment,
  }

  // Enviar para API
  fetch("checkoutAPI.php", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(checkoutData),
  })
    .then((response) => response.json())
    .then((data) => {
      if (data.success) {
        alert("Compra finalizada com sucesso! Número do pedido: " + data.order_id)
        window.location.href = "../success.php?order=" + data.order_id
      } else {
        alert("Erro ao finalizar compra: " + data.message)
      }
    })
    .catch((error) => {
      console.error("[v0] Checkout error:", error)
      alert("Erro ao processar sua compra.")
    })
}
