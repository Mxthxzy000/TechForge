<?php
session_start();
require_once '../config.php';

// Verificar se usuário está logado
if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit;
}

$user_id = $_SESSION['user_id'];

// Obter endereços salvos do usuário
$query_addresses = "SELECT id, street, number, complement, neighborhood, city, state, cep FROM addresses WHERE user_id = ? ORDER BY is_default DESC";
$stmt = $conn->prepare($query_addresses);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result_addresses = $stmt->get_result();
$addresses = $result_addresses->fetch_all(MYSQLI_ASSOC);

// Obter métodos de pagamento salvos
$query_payments = "SELECT id, payment_method, card_last_four, card_holder, is_default FROM payment_methods WHERE user_id = ? ORDER BY is_default DESC";
$stmt = $conn->prepare($query_payments);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result_payments = $stmt->get_result();
$payment_methods = $result_payments->fetch_all(MYSQLI_ASSOC);

// Obter carrinho (total de produtos)
$query_cart = "SELECT SUM(price * quantity) as total FROM cart WHERE user_id = ?";
$stmt = $conn->prepare($query_cart);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result_cart = $stmt->get_result()->fetch_assoc();
$cart_total = $result_cart['total'] ?? 0;
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout - TechForge</title>
    <link rel="stylesheet" href="out.css">
</head>
<body>
    <div class="checkout-container">
        <div class="checkout-content">
            <!-- Sidebar de Resumo -->
            <aside class="checkout-sidebar">
                <h2>Resumo do Pedido</h2>
                <div class="order-summary">
                    <div class="summary-item">
                        <span>Subtotal:</span>
                        <span id="subtotal">R$ <?php echo number_format($cart_total, 2, ',', '.'); ?></span>
                    </div>
                    <div class="summary-item">
                        <span>Frete:</span>
                        <span id="shipping-cost">R$ 0,00</span>
                    </div>
                    <div class="summary-divider"></div>
                    <div class="summary-item total">
                        <span>Total:</span>
                        <span id="total-amount">R$ <?php echo number_format($cart_total, 2, ',', '.'); ?></span>
                    </div>
                </div>
            </aside>

            <!-- Conteúdo Principal -->
            <main class="checkout-main">
                <h1>Finalizar Compra</h1>

                <!-- Seção de Endereço -->
                <section class="checkout-section">
                    <h2>Endereço de Entrega</h2>
                    
                    <!-- Seleção de Endereço Salvo -->
                    <div class="address-selector">
                        <h3>Meus Endereços</h3>
                        <div class="addresses-list" id="addressesList">
                            <?php if (empty($addresses)): ?>
                                <p class="empty-message">Nenhum endereço salvo. Adicione um novo.</p>
                            <?php else: ?>
                                <?php foreach ($addresses as $address): ?>
                                    <label class="address-card">
                                        <input type="radio" name="address" value="<?php echo $address['id']; ?>" class="address-radio" data-cep="<?php echo $address['cep']; ?>">
                                        <div class="address-info">
                                            <strong><?php echo htmlspecialchars($address['street']); ?>, <?php echo $address['number']; ?></strong>
                                            <?php if ($address['complement']): ?>
                                                <p><?php echo htmlspecialchars($address['complement']); ?></p>
                                            <?php endif; ?>
                                            <p><?php echo htmlspecialchars($address['neighborhood']); ?>, <?php echo htmlspecialchars($address['city']); ?> - <?php echo $address['state']; ?></p>
                                            <p class="cep">CEP: <?php echo $address['cep']; ?></p>
                                        </div>
                                    </label>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Buscar Novo Endereço por CEP -->
                    <div class="address-search">
                        <h3>Buscar Endereço por CEP</h3>
                        <div class="cep-input-group">
                            <input type="text" id="cepInput" placeholder="Digite seu CEP (ex: 01310-100)" class="cep-input">
                            <button id="searchCepBtn" class="btn btn-primary">Buscar</button>
                        </div>
                        
                        <div id="addressResult" class="address-result" style="display: none;">
                            <div class="form-group">
                                <label>Rua</label>
                                <input type="text" id="street" class="form-input" readonly>
                            </div>
                            <div class="form-row">
                                <div class="form-group">
                                    <label>Número</label>
                                    <input type="text" id="number" class="form-input" placeholder="123">
                                </div>
                                <div class="form-group">
                                    <label>Complemento</label>
                                    <input type="text" id="complement" class="form-input" placeholder="Apto, sala, etc">
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="form-group">
                                    <label>Bairro</label>
                                    <input type="text" id="neighborhood" class="form-input" readonly>
                                </div>
                                <div class="form-group">
                                    <label>Cidade</label>
                                    <input type="text" id="city" class="form-input" readonly>
                                </div>
                            </div>
                            <div class="form-group">
                                <label>Estado</label>
                                <input type="text" id="state" class="form-input" readonly>
                            </div>
                            <button id="selectNewAddressBtn" class="btn btn-secondary">Usar Este Endereço</button>
                        </div>
                    </div>
                </section>

                <!-- Seção de Frete -->
                <section class="checkout-section">
                    <h2>Opções de Frete</h2>
                    <div id="shippingOptions" class="shipping-options">
                        <p class="loading-message">Selecione um endereço para ver opções de frete</p>
                    </div>
                </section>

                <!-- Seção de Pagamento -->
                <section class="checkout-section">
                    <h2>Método de Pagamento</h2>
                    
                    <!-- Métodos Salvos -->
                    <div class="payment-selector">
                        <h3>Meus Métodos</h3>
                        <div class="payment-list" id="paymentList">
                            <?php if (empty($payment_methods)): ?>
                                <p class="empty-message">Nenhum método salvo. Adicione um novo.</p>
                            <?php else: ?>
                                <?php foreach ($payment_methods as $method): ?>
                                    <label class="payment-card">
                                        <input type="radio" name="payment_method" value="<?php echo $method['id']; ?>" class="payment-radio">
                                        <div class="payment-info">
                                            <strong><?php echo ucfirst($method['payment_method']); ?></strong>
                                            <?php if ($method['payment_method'] === 'credit_card'): ?>
                                                <p>Cartão terminado em <?php echo $method['card_last_four']; ?> - <?php echo htmlspecialchars($method['card_holder']); ?></p>
                                            <?php else: ?>
                                                <p><?php echo htmlspecialchars($method['card_holder']); ?></p>
                                            <?php endif; ?>
                                        </div>
                                    </label>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Adicionar Novo Método -->
                    <div class="payment-add">
                        <h3>Adicionar Método de Pagamento</h3>
                        <div class="payment-method-selector">
                            <label class="method-option">
                                <input type="radio" name="new_payment_type" value="credit_card">
                                <span>Cartão de Crédito</span>
                            </label>
                            <label class="method-option">
                                <input type="radio" name="new_payment_type" value="debit_card">
                                <span>Cartão de Débito</span>
                            </label>
                            <label class="method-option">
                                <input type="radio" name="new_payment_type" value="pix">
                                <span>PIX</span>
                            </label>
                        </div>

                        <div id="cardForm" class="payment-form" style="display: none;">
                            <div class="form-group">
                                <label>Nome do Titular</label>
                                <input type="text" id="cardHolder" class="form-input" placeholder="Nome como aparece no cartão">
                            </div>
                            <div class="form-group">
                                <label>Número do Cartão</label>
                                <input type="text" id="cardNumber" class="form-input" placeholder="1234 5678 9012 3456" maxlength="19">
                            </div>
                            <div class="form-row">
                                <div class="form-group">
                                    <label>Validade</label>
                                    <input type="text" id="cardExpiry" class="form-input" placeholder="MM/AA" maxlength="5">
                                </div>
                                <div class="form-group">
                                    <label>CVV</label>
                                    <input type="text" id="cardCVV" class="form-input" placeholder="123" maxlength="4">
                                </div>
                            </div>
                        </div>

                        <div id="pixForm" class="payment-form" style="display: none;">
                            <div class="pix-info">
                                <p>Use PIX para pagamento instantâneo. Você receberá um código QR para escanear.</p>
                                <div class="form-group">
                                    <label>Chave PIX</label>
                                    <input type="text" id="pixKey" class="form-input" placeholder="Sua chave PIX">
                                </div>
                            </div>
                        </div>
                    </div>
                </section>

                <!-- Botão de Finalizar -->
                <section class="checkout-actions">
                    <button id="finalizeBtn" class="btn btn-success">Finalizar Compra</button>
                </section>
            </main>
        </div>
    </div>

    <script>
        const cartTotal = <?php echo json_encode($cart_total); ?>;
        const shippingRates = {
            'SP': { 'standard': 15.00, 'fast': 25.00, 'express': 40.00 },
            'RJ': { 'standard': 18.00, 'fast': 28.00, 'express': 45.00 },
            'MG': { 'standard': 20.00, 'fast': 30.00, 'express': 50.00 },
            'default': { 'standard': 25.00, 'fast': 35.00, 'express': 60.00 }
        };
    </script>
    <script src="out.js"></script>
</body>
</html>
