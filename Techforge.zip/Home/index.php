<?php
require '../config.php';
require '../session.php';
require '../flash.php';
require '../chatbot/config.php';

if (!isset($conn)) {
    die("Erro: Conexão com banco de dados não estabelecida.");
}
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TechForge - Sua Loja de Tecnologia</title>

    <link rel="stylesheet" href="../Comum/common.css">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="../chatbot/style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Inter:ital,opsz,wght@0,14..32,100..900;1,14..32,100..900&display=swap"
        rel="stylesheet">
</head>

<body>
    <header>
        <div class="inicio-header">
            <div class="hamburguer-menu">
                <span></span>
                <span></span>
                <span></span>
            </div>
            <img src="../imagens/logo_header_TechForge.png" alt="TechForge Logo" class="logo">
        </div>
        <div class="final-header">
            <div class="usuario-menu">
                <button id="minha-conta" class="btn-header">
                    <ion-icon name="person-circle-outline"></ion-icon>
                </button>
            </div>
            <button id="carrinho" class="btn-header"><ion-icon name="cart-outline"></ion-icon></button>
        </div>
    </header>

    <div class="dropdown-user">
        <?php if (!empty($_SESSION['idUsuario'])): ?>
            <a href="../Perfil/perfil.php" class="menu-usuario"
                style="justify-content: space-between; align-items: center;">
                <span>Olá, <?php echo htmlspecialchars($_SESSION['nomeUsuario']); ?>...</span>

                <?php if (!empty($_SESSION['fotoUsuario'])): ?>
                    <img src="<?php echo htmlspecialchars($_SESSION['fotoUsuario']); ?>" alt="Foto do Usuário"
                        class="foto-usuario" style="width:26px;height:26px;border-radius:50%;object-fit:cover;">
                <?php else: ?>
                    <ion-icon name="person-circle-outline" class="icon-user"></ion-icon>
                <?php endif; ?>
            </a>

            <form method="POST" action="../logout.php">
                <button type="submit" class="menu-usuario">
                    Sair!
                    <ion-icon name="log-out-outline" class="icon-user"></ion-icon>
                </button>
            </form>

        <?php else: ?>
            <a href="../Login/login.php" class="menu-usuario">
                Fazer Login!
                <ion-icon name="log-in-outline" class="icon-user"></ion-icon>
            </a>
        <?php endif; ?>
    </div>

    <nav>
        <ul>
            <li><a href="../Catalogo/catalogo.php">PRODUTOS</a> <ion-icon name="bag-outline" class="navicon"></ion-icon>
            </li>
            <span class="linha"></span>
            <li><a href="../MontarPC/montarpc.php">MONTE SEU PC</a> <ion-icon class="navicon" name="desktop-outline"></ion-icon> </li>
            <span class="linha"></span>
            <li><a href="../Sobre/sobre.php">SOBRE NÓS</a> <ion-icon class="navicon" name="business-outline"></ion-icon>
            </li>
        </ul>
    </nav>

    <?php show_flash(); ?>

    <main>
        <div class="slider">
            <div class="slides">
                <input type="radio" name="radio-btn" id="radio1">
                <input type="radio" name="radio-btn" id="radio2">
                <input type="radio" name="radio-btn" id="radio3">
                <input type="radio" name="radio-btn" id="radio4">

                <div class="slide first">
                    <img src="../imagens/banner parceria com a karol.png" alt="Slide 1">
                </div>

                <div class="slide">
                    <img src="../imagens/rick sanchez banner.png" alt="Slide2">
                </div>

                <div class="slide">
                    <img src="../imagens/banner vermelho.png" alt="Slide3">
                </div>

                <div class="slide">
                    <img src="../imagens/mês da criança.png" alt="Slide4">
                </div>

                <div class="autonavegar">
                    <div class="auto-btn1"></div>
                    <div class="auto-btn2"></div>
                    <div class="auto-btn3"></div>
                    <div class="auto-btn4"></div>
                </div>

                <div class="manual-navegar">
                    <label for="radio1" class="manual-btn"></label>
                    <label for="radio2" class="manual-btn"></label>
                    <label for="radio3" class="manual-btn"></label>
                    <label for="radio4" class="manual-btn"></label>
                </div>
            </div>
        </div>

        <div class="mincard">
            <div class="card1">
                <h2>PREÇOS BAIXOS</h2>
                <img src="../imagens/preçosBaixos.png" alt="preços baixos" id="preços-baixos">
            </div>

            <div class="card1">
                <h2>SERVIÇOS DE MONTAGEM</h2>
                <img src="../imagens/serviçoMontagem.png" alt="serviços de montagem" id="serviços-montagem">
            </div>

            <div class="card1">
                <h2>EXCELENTE QUALIDADE</h2>
                <img src="../imagens/excelenteQualidade.png" alt="excelente qualidade" id="excelente-qualidade">
            </div>

            <div class="card1">
                <h2>CUPONS DE DESCONTO</h2>
                <img src="../imagens/cuponsDesconto.png" alt=" cupons de desconto" id="cupons-desconto">
            </div>

            <div class="card1">
                <h2>PARCELAS DE ATÉ 12X</h2>
                <img src="../imagens/parcelas12x.png" alt="parcelas de até 12x" id="parcelas-12x">
            </div>
        </div>

        <div class="cards-produtos">
            <?php
            // Verifica se a coluna vendasProduto existe
            $check_column = $conn->query("SHOW COLUMNS FROM produtos LIKE 'vendasProduto'");

            if ($check_column && $check_column->num_rows > 0) {
                // Coluna existe, ordena por vendas
                $query = "SELECT * FROM produtos ORDER BY vendasProduto DESC LIMIT 10";
            } else {
                // Coluna não existe, ordena por ID (produtos mais recentes)
                $query = "SELECT * FROM produtos ORDER BY idProduto DESC LIMIT 10";
                error_log("AVISO: Coluna 'vendasProduto' não encontrada. Execute o script 'fix_vendas_produto_column.sql'");
            }

            $result = $conn->query($query);

            if (!$result) {
                echo "<p>Erro ao carregar produtos: " . htmlspecialchars($conn->error) . "</p>";
                error_log("Erro na query de produtos: " . $conn->error);
            } elseif ($result->num_rows > 0) {
                $rank = 1;
                while ($row = $result->fetch_assoc()):
                    ?>
                    <div class="card-produto">
                        <?php if ($check_column && $rank <= 3): ?>
                            <span class="badge">Mais Vendidos</span>
                        <?php endif; ?>

                        <img src="<?= htmlspecialchars($row['imagem']) ?>" alt="<?= htmlspecialchars($row['nomeProduto']) ?>">

                        <div class="card-info">
                            <h3><?= htmlspecialchars($row['nomeProduto']) ?></h3>
                            <p class="descricao"><?= htmlspecialchars($row['descricaoProduto']) ?></p>

                            <p class="preco-atual">
                                R$ <?= number_format($row['valorProduto'], 2, ',', '.') ?> <span>à vista</span>
                            </p>
                            <p class="parcelamento">
                                12x de R$ <?= number_format($row['valorProduto'] / 12, 2, ',', '.') ?> sem juros
                            </p>
                        </div>

                        <div class="card-buttons">
                            <button class="btn-add-cart" data-id="<?= $row['idProduto'] ?>" title="Adicionar ao carrinho">
                                <ion-icon name="cart-outline"></ion-icon>
                                Adicionar
                            </button>
                            <button class="btn-see-more" data-id="<?= $row['idProduto'] ?>" title="Ver mais detalhes">
                                <ion-icon name="eye-outline"></ion-icon>
                                Ver Mais
                            </button>
                        </div>
                    </div>
                    <?php
                    $rank++;
                endwhile;
            } else {
                echo "<p>Nenhum produto encontrado no momento.</p>";
            }
            ?>
        </div>

    </main>
    <button class="chat-toggle-button" id="chatToggleButton">
        <ion-icon name="chatbox-outline"></ion-icon>
    </button>

    <div class="chat-container" id="chatContainer" style="display: none;">
        <div class="chat-header">
            <button class="close-button" id="closeButton">
               <ion-icon name="close-outline"></ion-icon>
            </button>
            <h1>ChatBot</h1>
            <p>Techforge Assistant</p>
        </div>

        <div class="chat-messages" id="chatMessages">
            <div class="message assistant">
                <div class="message-content">
                    Bem-vindo ao suporte da TechForge! 🔧💻 Aqui você encontra as melhores soluções em hardware e acessórios de alta performance. Como posso te ajudar hoje? - ❓ Dúvidas sobre produtos - 🚚 Status ou rastreio do seu pedido - 🛠️ Garantia e suporte técnico - 🛒 Ajuda para realizar uma compra Estou aqui para garantir que você tenha a melhor experiência com a TechForge. Me diga, em que podemos ajudar?
                    <div class="message-time">
                        <?php echo date('H:i'); ?>
                    </div>
                </div>
            </div>
        </div>

        <div class="typing-indicator" id="typingIndicator">
            <div class="typing-dots">
                <div class="typing-dot"></div>
                <div class="typing-dot"></div>
                <div class="typing-dot"></div>
            </div>
        </div>

        <div class="chat-input-container">
            <form class="chat-input-form" id="chatForm">
                <input type="text" class="chat-input" id="messageInput" placeholder="Digite sua mensagem..."
                    autocomplete="off" required>
                <button type="submit" class="send-button" id="sendButton">
                    Enviar
                </button>
            </form>
        </div>
    </div>
    <script src="../chatbot/script.js"></script>
    <footer>
        <div class="container-footer">
            <ul>
                <h3>TECHFORGE</h3>
                <div class="links">
                    <li><a href="../Sobre/sobre.php">Sobre nós</a></li>
                    <li><a href="#">Política De Privacidade</a></li>
                </div>
            </ul>

            <ul>
                <h3>AJUDA</h3>
                <div class="links">
                    <li><a href="../Fale Conosco/fale.php">Fale Conosco</a></li>
                    <li><a href="../Perfil/perfil.php">Sua Conta</a></li>
                </div>
            </ul>

            <ul>
                <h3>SERVIÇOS</h3>
                <div class="links">
                    <li><a href="../Catalogo/catalogo.php">Catálogo</a></li>
                    <li><a href="../Fale Conosco/fale.php">Suporte</a></li>
                </div>
            </ul>

            <ul>
                <h3>SIGA-NOS</h3>
                <div class="links-icon">
                    <ion-icon name="logo-instagram"></ion-icon>
                    <ion-icon name="logo-youtube"></ion-icon>
                    <ion-icon name="logo-linkedin"></ion-icon>
                </div>
                <div class="title">
                    <p>Em Nossas Redes Sociais</p>
                </div>
            </ul>
        </div>
        

        <p id="finalfooter"> ©2025 TechForge. Todos os Direitos Reservados | Caçapava SP </p>
    </footer>

    <!-- Incluindo script comum e específico -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="../js/notification.js"></script>
    <script src="../Comum/common.js"></script>
    <script src="script.js"></script>
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
</body>

</html>
