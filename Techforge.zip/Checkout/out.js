document.addEventListener('DOMContentLoaded', function() {
    console.log('Checkout carregando...');
    
    // Elementos principais - com verificações de null
    const savedPaymentMethodsContainer = document.getElementById('savedPaymentMethods');
    const savedAddressesContainer = document.getElementById('savedAddresses');
    const finalizeOrderBtn = document.getElementById('finalizeOrderBtn');
    const shippingOptionsContainer = document.getElementById('shipping-options');
    const calculateShippingBtn = document.getElementById('calculate-shipping');
    const cepInput = document.getElementById('cep');
    const addNewAddressBtn = document.getElementById('addNewAddress');
    
    console.log('Elementos encontrados:', {
        savedPaymentMethodsContainer: !!savedPaymentMethodsContainer,
        savedAddressesContainer: !!savedAddressesContainer,
        finalizeOrderBtn: !!finalizeOrderBtn,
        shippingOptionsContainer: !!shippingOptionsContainer,
        calculateShippingBtn: !!calculateShippingBtn,
        cepInput: !!cepInput,
        addNewAddressBtn: !!addNewAddressBtn
    });
    
    // URLs das APIs
    const checkoutApiUrl = 'checkoutAPI.php';
    
    // Função para mostrar loading
    function showLoading(title, text) {
        Swal.fire({
            title: title,
            text: text,
            allowOutsideClick: false,
            didOpen: () => {
                Swal.showLoading();
            }
        });
    }
    
    // Função para fazer requisições
    async function fetchData(url, options = {}) {
        try {
            console.log('Fazendo requisição para:', url);
            const response = await fetch(url, options);
            const data = await response.json();
            console.log('Resposta recebida:', data);
            return data;
        } catch (error) {
            console.error('Erro na requisição:', error);
            throw error;
        }
    }
    
    // CARREGAR ENDEREÇOS SALVOS
    async function loadSavedAddresses() {
        console.log('Carregando endereços...');
        
        if (!savedAddressesContainer) {
            console.error('Container de endereços não encontrado!');
            return;
        }
        
        showLoading('Carregando...', 'Buscando endereços salvos...');
        
        try {
            const data = await fetchData(`${checkoutApiUrl}?action=getSavedAddresses`);
            Swal.close();
            
            console.log('Dados dos endereços:', data);
            
            if (data.success && data.addresses && data.addresses.length > 0) {
                savedAddressesContainer.innerHTML = data.addresses.map((address, index) => `
                    <div class="address-option" style="border: 1px solid #e2e8f0; padding: 15px; border-radius: 8px; margin-bottom: 10px;">
                        <label class="payment-label" style="display: flex; align-items: flex-start; gap: 10px; cursor: pointer;">
                            <input type="radio" name="deliveryAddress" value="${address.idEndereco}" 
                                   ${index === 0 ? 'checked' : ''} 
                                   style="margin-top: 3px;">
                            <div class="address-info">
                                <p style="margin: 0 0 5px 0; font-weight: bold;">${getTipoLabel(address.tipoEndereco)}</p>
                                <p style="margin: 0 0 5px 0;">${address.rua}, ${address.numero || 'S/N'} ${address.complemento ? ' - ' + address.complemento : ''}</p>
                                <p style="margin: 0 0 5px 0;">${address.bairro}, ${address.cidade} - ${address.estado}</p>
                                <p style="margin: 0; color: #666;">CEP: ${address.cep}</p>
                            </div>
                        </label>
                    </div>
                `).join('');
                
                console.log('Endereços carregados com sucesso!');
                updateFinalizeButton();
                
            } else {
                savedAddressesContainer.innerHTML = `
                    <div style="text-align: center; padding: 20px; color: #666;">
                        <p>Nenhum endereço cadastrado</p>
                        <button type="button" onclick="window.location.href='../Perfil/perfil.php'" 
                                style="background: #3b82f6; color: white; border: none; padding: 10px 15px; border-radius: 5px; cursor: pointer; margin-top: 10px;">
                            Cadastrar Endereço
                        </button>
                    </div>
                `;
            }
            
        } catch (error) {
            console.error('Erro ao carregar endereços:', error);
            savedAddressesContainer.innerHTML = `
                <div style="text-align: center; padding: 20px; color: #ef4444;">
                    <p>Erro ao carregar endereços</p>
                </div>
            `;
            Swal.close();
        }
    }
    
    // CARREGAR MÉTODOS DE PAGAMENTO SALVOS
    async function loadSavedPaymentMethods() {
        console.log('Carregando métodos de pagamento...');
        
        if (!savedPaymentMethodsContainer) {
            console.error('Container de pagamentos não encontrado!');
            return;
        }
        
        showLoading('Carregando...', 'Buscando formas de pagamento salvas...');
        
        try {
            const data = await fetchData(`${checkoutApiUrl}?action=getSavedPaymentMethods`);
            Swal.close();
            
            console.log('Dados dos pagamentos:', data);
            
            if (data.success && data.paymentMethods && data.paymentMethods.length > 0) {
                savedPaymentMethodsContainer.innerHTML = data.paymentMethods.map((method, index) => `
                    <div class="payment-option" style="border: 1px solid #e2e8f0; padding: 15px; border-radius: 8px; margin-bottom: 10px;">
                        <label class="payment-label" style="display: flex; align-items: center; gap: 10px; cursor: pointer;">
                            <input type="radio" name="savedPaymentMethod" value="${method.id}" 
                                   ${index === 0 ? 'checked' : ''}>
                            <div style="flex: 1;">
                                <p style="margin: 0 0 5px 0; font-weight: bold;">${method.brand} **** ${method.last4}</p>
                                <p style="margin: 0 0 5px 0; color: #666;">Titular: ${method.holder}</p>
                                <p style="margin: 0; color: #666;">Validade: ${method.expiry}</p>
                            </div>
                        </label>
                    </div>
                `).join('');
                
                console.log('Métodos de pagamento carregados com sucesso!');
                updateFinalizeButton();
                
            } else {
                savedPaymentMethodsContainer.innerHTML = `
                    <div style="text-align: center; padding: 20px; color: #666;">
                        <p>Nenhum cartão salvo</p>
                    </div>
                `;
            }
            
        } catch (error) {
            console.error('Erro ao carregar métodos de pagamento:', error);
            savedPaymentMethodsContainer.innerHTML = `
                <div style="text-align: center; padding: 20px; color: #ef4444;">
                    <p>Erro ao carregar métodos de pagamento</p>
                </div>
            `;
            Swal.close();
        }
    }
    
    // CALCULAR FRETE - COM VERIFICAÇÃO DE NULL
    if (calculateShippingBtn && cepInput) {
        console.log('Configurando cálculo de frete...');
        
        calculateShippingBtn.addEventListener('click', async function() {
            const cep = cepInput.value.replace(/\D/g, '');
            
            if (cep.length !== 8) {
                Swal.fire({
                    icon: 'error',
                    title: 'CEP Inválido',
                    text: 'Por favor, insira um CEP válido com 8 dígitos.'
                });
                return;
            }
            
            console.log('Calculando frete para CEP:', cep);
            showLoading('Calculando...', 'Buscando opções de frete...');
            
            try {
                const formData = new FormData();
                formData.append('action', 'calculateShipping');
                formData.append('cep', cep);
                
                const data = await fetchData(checkoutApiUrl, {
                    method: 'POST',
                    body: formData
                });
                
                Swal.close();
                console.log('Resposta do frete:', data);
                
                if (data.success && data.shippingOptions && shippingOptionsContainer) {
                    shippingOptionsContainer.innerHTML = data.shippingOptions.map((option, index) => `
                        <div class="shipping-option" style="margin: 10px 0; padding: 10px; border: 1px solid #e2e8f0; border-radius: 5px;">
                            <label style="display: flex; align-items: center; gap: 10px; cursor: pointer;">
                                <input type="radio" name="shippingOption" value="${option.id}" 
                                       ${index === 0 ? 'checked' : ''}>
                                <div style="flex: 1;">
                                    <div style="font-weight: bold;">${option.name}</div>
                                    <div style="color: #666;">
                                        R$ ${option.price.toFixed(2).replace('.', ',')} - ${option.days}
                                    </div>
                                </div>
                            </label>
                        </div>
                    `).join('');
                    
                    // Adicionar event listeners aos novos radios de frete
                    shippingOptionsContainer.querySelectorAll('input[name="shippingOption"]').forEach(radio => {
                        radio.addEventListener('change', updateFinalizeButton);
                    });
                    
                    console.log('Frete calculado com sucesso!');
                    updateFinalizeButton();
                    
                } else {
                    if (shippingOptionsContainer) {
                        shippingOptionsContainer.innerHTML = `
                            <div style="text-align: center; padding: 10px; color: #ef4444;">
                                <p>${data.error || 'Erro ao calcular frete'}</p>
                            </div>
                        `;
                    }
                }
                
            } catch (error) {
                console.error('Erro ao calcular frete:', error);
                if (shippingOptionsContainer) {
                    shippingOptionsContainer.innerHTML = `
                        <div style="text-align: center; padding: 10px; color: #ef4444;">
                            <p>Erro ao calcular frete</p>
                        </div>
                    `;
                }
                Swal.close();
            }
        });
    } else {
        console.warn('Elementos de frete não encontrados:', {
            calculateShippingBtn: !!calculateShippingBtn,
            cepInput: !!cepInput
        });
    }
    
    // Botão de adicionar novo endereço - COM VERIFICAÇÃO
    if (addNewAddressBtn) {
        addNewAddressBtn.addEventListener('click', function() {
            window.location.href = '../Perfil/perfil.php';
        });
    } else {
        console.warn('Botão addNewAddressBtn não encontrado');
    }
    
    // Formatação do CEP - COM VERIFICAÇÃO
    if (cepInput) {
        cepInput.addEventListener('input', function(event) {
            let value = event.target.value.replace(/\D/g, '');
            if (value.length > 5) {
                value = value.replace(/^(\d{5})(\d)/, '$1-$2');
            }
            event.target.value = value;
        });
    }
    
    // Botão finalizar pedido - COM VERIFICAÇÃO
    if (finalizeOrderBtn) {
        finalizeOrderBtn.addEventListener('click', function() {
            const selectedAddress = document.querySelector('input[name="deliveryAddress"]:checked');
            const selectedPayment = document.querySelector('input[name="payment"]:checked') || 
                                  document.querySelector('input[name="savedPaymentMethod"]:checked');
            const selectedShipping = document.querySelector('input[name="shippingOption"]:checked');
            
            console.log('Finalizando pedido com:', {
                address: selectedAddress?.value,
                payment: selectedPayment?.value, 
                shipping: selectedShipping?.value
            });
            
            Swal.fire({
                icon: 'success',
                title: 'Pedido Finalizado!',
                text: 'Seu pedido foi processado com sucesso!',
                confirmButtonText: 'OK'
            });
        });
    } else {
        console.warn('Botão finalizeOrderBtn não encontrado');
    }
    
    // Função auxiliar para labels de tipo de endereço
    function getTipoLabel(tipo) {
        const labels = {
            entrega: "🏠 Endereço de Entrega",
            cobranca: "💰 Endereço de Cobrança", 
            outro: "📦 Outro Endereço"
        };
        return labels[tipo] || "📍 Endereço";
    }
    
    // Atualizar botão de finalizar
    function updateFinalizeButton() {
        if (!finalizeOrderBtn) {
            console.warn('Botão finalizeOrderBtn não disponível para atualização');
            return;
        }
        
        const hasAddress = document.querySelector('input[name="deliveryAddress"]:checked');
        const hasPayment = document.querySelector('input[name="payment"]:checked') || 
                          document.querySelector('input[name="savedPaymentMethod"]:checked');
        const hasShipping = document.querySelector('input[name="shippingOption"]:checked');
        
        console.log('Status do botão finalizar:', { hasAddress, hasPayment, hasShipping });
        
        if (hasAddress && hasPayment && hasShipping) {
            finalizeOrderBtn.style.display = 'block';
            console.log('Botão de finalizar habilitado!');
        } else {
            finalizeOrderBtn.style.display = 'none';
        }
    }
    
    // Adicionar event listeners para atualização em tempo real
    document.addEventListener('change', function(event) {
        if (event.target.name === 'deliveryAddress' || 
            event.target.name === 'payment' || 
            event.target.name === 'savedPaymentMethod' ||
            event.target.name === 'shippingOption') {
            updateFinalizeButton();
        }
    });
    
    // INICIALIZAÇÃO
    console.log('Iniciando carregamento dos dados...');
    loadSavedAddresses();
    loadSavedPaymentMethods();
    
    // Header e navegação (com verificações)
    const hamburguerMenu = document.querySelector('.hamburguer-menu');
    const nav = document.querySelector('nav');
    const minhaContaBtn = document.getElementById('minha-conta');
    const dropdownUser = document.querySelector('.dropdown-user');

    if (hamburguerMenu && nav) {
        hamburguerMenu.addEventListener('click', () => {
            nav.classList.toggle('active');
            hamburguerMenu.classList.toggle('active');
        });
    } else {
        console.warn('Elementos do menu hamburguer não encontrados');
    }

    if (minhaContaBtn && dropdownUser) {
        minhaContaBtn.addEventListener('click', (event) => {
            dropdownUser.classList.toggle('active');
            event.stopPropagation();
        });

        document.addEventListener('click', (event) => {
            if (!dropdownUser.contains(event.target) && !minhaContaBtn.contains(event.target)) {
                dropdownUser.classList.remove('active');
            }
        });
    } else {
        console.warn('Elementos do dropdown do usuário não encontrados');
    }
    
    console.log('Checkout inicializado com sucesso!');
});