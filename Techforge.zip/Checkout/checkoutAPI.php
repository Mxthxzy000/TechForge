<?php
require '../config.php';
require '../session.php';

header('Content-Type: application/json; charset=utf-8');

if (empty($_SESSION['idUsuario'])) {
    echo json_encode(['error' => 'Usuário não autenticado']);
    exit;
}

$idUsuario = $_SESSION['idUsuario'];
$action = $_POST['action'] ?? $_GET['action'] ?? '';

// Buscar endereços salvos - MESMA LÓGICA DO PERFIL
if ($action === 'getSavedAddresses') {
    $stmt = $conn->prepare("SELECT * FROM endereco WHERE idUsuario = ? ORDER BY tipoEndereco, idEndereco");
    $stmt->bind_param('i', $idUsuario);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $addresses = [];
    while ($row = $result->fetch_assoc()) {
        $addresses[] = [
            'idEndereco' => $row['idEndereco'],
            'rua' => $row['rua'],
            'numero' => $row['numero'],
            'complemento' => $row['complemento'],
            'bairro' => $row['bairro'],
            'cidade' => $row['cidade'],
            'estado' => $row['estado'],
            'cep' => $row['cep'],
            'tipoEndereco' => $row['tipoEndereco']
        ];
    }
    
    echo json_encode(['success' => true, 'addresses' => $addresses]);
    exit;
}

// Buscar métodos de pagamento salvos - MESMA LÓGICA DO PERFIL
if ($action === 'getSavedPaymentMethods') {
    $sql = "SELECT idFormaPagamento, tipoPagamento, nomeTitular, numeroCartao, validadeCartao, 
            bandeiraCartao, chavePix, cpfTitular, dataCadastro 
            FROM formas_pagamento 
            WHERE idUsuario = ? 
            ORDER BY dataCadastro DESC";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $idUsuario);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $paymentMethods = [];
    while ($row = $result->fetch_assoc()) {
        // Formatar para exibição
        if ($row['tipoPagamento'] === 'cartao_credito') {
            $paymentMethods[] = [
                'id' => $row['idFormaPagamento'],
                'brand' => $row['bandeiraCartao'],
                'last4' => $row['numeroCartao'],
                'holder' => $row['nomeTitular'],
                'expiry' => $row['validadeCartao'],
                'type' => 'cartao'
            ];
        }
    }
    
    echo json_encode(['success' => true, 'paymentMethods' => $paymentMethods]);
    exit;
}

// Calcular frete
if ($action === 'calculateShipping') {
    $cep = preg_replace('/[^0-9]/', '', $_POST['cep'] ?? '');
    
    if (strlen($cep) !== 8) {
        echo json_encode(['error' => 'CEP inválido']);
        exit;
    }
    
    // Simulação de cálculo de frete
    $shippingOptions = [
        [
            'id' => 'express',
            'name' => 'Entrega Expressa',
            'price' => 25.90,
            'days' => '2-3 dias úteis'
        ],
        [
            'id' => 'standard',
            'name' => 'Entrega Padrão',
            'price' => 15.90,
            'days' => '5-7 dias úteis'
        ],
        [
            'id' => 'economy',
            'name' => 'Entrega Econômica',
            'price' => 9.90,
            'days' => '8-12 dias úteis'
        ]
    ];
    
    echo json_encode([
        'success' => true,
        'shippingOptions' => $shippingOptions
    ]);
    exit;
}

echo json_encode(['error' => 'Ação inválida: ' . $action]);
exit;
?>